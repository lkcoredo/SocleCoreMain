package dev.socle.soclemovies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoclemoviesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoclemoviesApplication.class, args);
	}

}
